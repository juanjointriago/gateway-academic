# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution.

## Credential Values

- Android keystore password: 22f957f00631e6c908b444855b89d203
- Android key alias: 40c417a8ceedb7799fafc6773ee23c74
- Android key password: b38a39231b5d712b59ccaac55cb910f4
      